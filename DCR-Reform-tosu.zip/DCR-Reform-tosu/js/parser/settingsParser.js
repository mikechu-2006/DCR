function createSet(values) {
    return new Set((values || []).map((item) => String(item).toLowerCase()));
}

export function normalizeContentBarValue(value) {
    if (typeof value !== "string") {
        return null;
    }

    const lowered = value.trim().toLowerCase();
    if (lowered === "auto") return "Auto";
    if (lowered === "pattern") return "Pattern";
    if (lowered === "etterna") return "Etterna";
    if (lowered === "graph") return "Graph";
    if (lowered === "full") return "Full";
    if (lowered === "none") return "None";
    if (lowered === "reworkpp") return "ReworkPP";
    return null;
}

export function normalizeSrTextValue(value) {
    if (typeof value !== "string") {
        return null;
    }

    const lowered = value.trim().toLowerCase();
    if (lowered === "auto") return "Auto";
    if (lowered === "reworksr") return "ReworkSR";
    if (lowered === "msd") return "MSD";
    if (lowered === "pattern") return "Pattern";
    if (lowered === "interludesr") return "InterludeSR";
    if (lowered === "reworkpp") return "ReworkPP";
    return null;
}

export function normalizeEstimatorAlgorithmValue(value) {
    if (typeof value !== "string") {
        return null;
    }

    const lowered = value.trim().toLowerCase();
    if (lowered === "azusa") return "Azusa";
    if (lowered === "roxy") return "Roxy";
    if (lowered === "mixed") return "Mixed";
    if (lowered === "mix") return "Mixed";
    if (lowered === "sunny") return "Sunny";
    if (lowered === "dcr") return "DCR";
    if (lowered === "cm3p_ext") return "CM3P_ext";
    if (lowered === "rework") return "Sunny";
    if (lowered === "direct") return "Sunny";
    if (lowered === "daniel") return "Daniel";
    if (lowered === "companella") return "Companella";
    if (lowered === "campanella") return "Companella";
    return null;
}

export function normalizeGameClientValue(value) {
    if (typeof value !== "string") {
        return null;
    }

    const lowered = value.trim().toLowerCase();
    if (lowered === "auto") return "Auto";
    if (lowered === "osu!" || lowered === "osu") return "Osu!";
    if (lowered === "etterna") return "Etterna";
    // 必须放在精确匹配 "malody" 之前（Malody 4 与 Malody V 是两个独立源）。
    if (lowered === "malody4" || lowered === "malody 4" || lowered === "malody-4") return "Malody4";
    if (lowered === "malody") return "Malody";
    return null;
}

export function normalizeEtternaVersionValue(value) {
    if (typeof value !== "string") {
        return null;
    }

    const trimmed = value.trim();
    if (trimmed === "0.68.0") {
        return "0.68.0-Unofficial";
    }
    return trimmed.length > 0 ? trimmed : null;
}

export function normalizeCardOpacityValue(value) {
    if (typeof value === "number" && Number.isFinite(value)) {
        const clamped = Math.max(0, Math.min(100, Math.round(value)));
        return `${clamped}%`;
    }

    if (typeof value !== "string") {
        return null;
    }

    const trimmed = value.trim();
    if (!trimmed) {
        return null;
    }

    const match = trimmed.match(/^(\d{1,3})(%)?$/);
    if (!match) {
        return null;
    }

    const numeric = Number.parseInt(match[1], 10);
    if (!Number.isFinite(numeric)) {
        return null;
    }

    const clamped = Math.max(0, Math.min(100, numeric));
    return `${clamped}%`;
}

export function normalizeCardRadiusValue(value) {
    if (typeof value !== "string") {
        return null;
    }

    const lowered = value.trim().toLowerCase();
    if (lowered === "small") return "Small";
    if (lowered === "medium") return "Medium";
    if (lowered === "large") return "Large";
    return null;
}

// Background blur strength for the Pattern/Etterna/Graph cover layers. Accepts a
// number (px), a "<n>px"/"<n>" string, or "Off"/"None" → "Off". Anything else
// returns null so callers fall back to the configured default.
export function normalizeCardBgBlurValue(value) {
    if (typeof value === "number" && Number.isFinite(value)) {
        const clamped = Math.max(0, Math.min(40, Math.round(value)));
        return clamped === 0 ? "Off" : `${clamped}px`;
    }

    if (typeof value !== "string") {
        return null;
    }

    const trimmed = value.trim();
    if (!trimmed) {
        return null;
    }

    const lowered = trimmed.toLowerCase();
    if (lowered === "off" || lowered === "none" || lowered === "0" || lowered === "0px") {
        return "Off";
    }

    const match = trimmed.match(/^(\d{1,3})(px)?$/i);
    if (!match) {
        return null;
    }

    const numeric = Number.parseInt(match[1], 10);
    if (!Number.isFinite(numeric)) {
        return null;
    }

    const clamped = Math.max(0, Math.min(40, numeric));
    return clamped === 0 ? "Off" : `${clamped}px`;
}

export function normalizeWsEndpointValue(value, fallback = "localhost:24050") {
    if (typeof value !== "string") {
        return fallback;
    }

    let normalized = value.trim();
    if (!normalized) {
        return fallback;
    }

    normalized = normalized.replace(/^(wss?:\/\/|https?:\/\/)/i, "");
    const slashIndex = normalized.indexOf("/");
    if (slashIndex >= 0) {
        normalized = normalized.slice(0, slashIndex);
    }

    normalized = normalized.trim();
    return normalized || fallback;
}

export function normalizeDiffTextValue(value) {
    if (typeof value !== "string") {
        return null;
    }

    const lowered = value.trim().toLowerCase();
    if (lowered === "none") return "None";
    if (lowered === "msd") return "MSD";
    if (lowered === "pattern") return "Pattern";
    if (lowered === "reworksr") return "ReworkSR";
    if (lowered === "interludesr") return "InterludeSR";
    if (lowered === "graph") return "Graph";
    if (lowered === "difficulty") return "Difficulty";
    return null;
}

export function normalizeBooleanSetting(value, fallback = false) {
    if (typeof value === "boolean") {
        return value;
    }
    if (typeof value === "number") {
        return value !== 0;
    }
    if (typeof value === "string") {
        const normalized = value.trim().toLowerCase();
        if (normalized === "true") return true;
        if (normalized === "false") return false;
        if (normalized === "1") return true;
        if (normalized === "0") return false;
    }
    if (value === undefined || value === null) {
        return fallback;
    }
    return Boolean(value);
}

export function normalizeCustomBackgroundColorValue(value) {
    if (typeof value !== "string") {
        return null;
    }

    if (/^#[0-9a-fA-F]{6}$/.test(value)) {
        return value.toLowerCase();
    }

    return null;
}

export function extractSettingValue(settingsPayload, settingKey) {
    if (Array.isArray(settingsPayload)) {
        const item = settingsPayload.find((entry) => entry?.uniqueID === settingKey);
        return item?.value;
    }

    if (settingsPayload && typeof settingsPayload === "object") {
        if (Object.prototype.hasOwnProperty.call(settingsPayload, settingKey)) {
            return settingsPayload[settingKey];
        }

        if (settingsPayload.settings && typeof settingsPayload.settings === "object") {
            const nested = settingsPayload.settings;
            if (Object.prototype.hasOwnProperty.call(nested, settingKey)) {
                return nested[settingKey];
            }
        }
    }

    return undefined;
}

export function createSettingsParsers(appConfig) {
    const contentBarSet = createSet(appConfig?.options?.contentBar);
    const srTextSet = createSet(appConfig?.options?.srText);
    const diffTextSet = createSet(appConfig?.options?.diffText);
    const estimatorAlgorithmSet = createSet(appConfig?.options?.estimatorAlgorithm);
    const etternaVersionSet = createSet(appConfig?.options?.etternaVersion);
    const companellaEtternaVersionSet = createSet(
        appConfig?.options?.companellaEtternaVersion || appConfig?.options?.etternaVersion,
    );
    const cardOpacitySet = createSet(appConfig?.options?.cardOpacity);
    const cardRadiusSet = createSet(appConfig?.options?.cardRadius);
    const cardBgBlurSet = createSet(appConfig?.options?.cardBgBlur);

    function parseEnablePatternValue(settingsPayload) {
        if (Array.isArray(settingsPayload)) {
            const item = settingsPayload.find((entry) => entry?.uniqueID === "enablePatternAnalysis");
            return normalizeBooleanSetting(item?.value, false);
        }

        if (settingsPayload && typeof settingsPayload === "object") {
            if (Object.prototype.hasOwnProperty.call(settingsPayload, "enablePatternAnalysis")) {
                return normalizeBooleanSetting(settingsPayload.enablePatternAnalysis, false);
            }

            if (settingsPayload.settings && typeof settingsPayload.settings === "object") {
                const nested = settingsPayload.settings;
                if (Object.prototype.hasOwnProperty.call(nested, "enablePatternAnalysis")) {
                    return normalizeBooleanSetting(nested.enablePatternAnalysis, false);
                }
            }
        }

        return false;
    }

    function parseContentBarValue(settingsPayload) {
        const value = extractSettingValue(settingsPayload, "contentBar");
        const normalized = normalizeContentBarValue(value);
        if (normalized && contentBarSet.has(normalized.toLowerCase())) {
            return normalized;
        }

        const enabled = parseEnablePatternValue(settingsPayload);
        return enabled ? "Pattern" : "None";
    }

    function parseSrTextValue(settingsPayload) {
        const value = extractSettingValue(settingsPayload, "srText");
        const normalized = normalizeSrTextValue(value);
        if (normalized && srTextSet.has(normalized.toLowerCase())) {
            return normalized;
        }
        return appConfig.defaults.srText;
    }

    function parseDebugUseAmountValue(settingsPayload) {
        const value = extractSettingValue(settingsPayload, "debugUseAmount");
        return normalizeBooleanSetting(value, appConfig.defaults.debugUseAmount);
    }

    function parseDiffTextValue(settingsPayload) {
        const value = extractSettingValue(settingsPayload, "diffText");
        const normalized = normalizeDiffTextValue(value);
        if (normalized && diffTextSet.has(normalized.toLowerCase())) {
            return normalized;
        }

        const legacyEnable = extractSettingValue(settingsPayload, "enableEstDiff");
        if (legacyEnable === undefined || legacyEnable === null) {
            return appConfig.defaults.diffText;
        }
        return normalizeBooleanSetting(legacyEnable, true) ? "Difficulty" : "None";
    }

    function parseAutoModeValue(settingsPayload) {
        const value = extractSettingValue(settingsPayload, "autoMode");
        return normalizeBooleanSetting(value, appConfig.defaults.autoMode);
    }

    function parseEstimatorAlgorithmValue(settingsPayload) {
        const value = extractSettingValue(settingsPayload, "estimatorAlgorithm");
        const normalized = normalizeEstimatorAlgorithmValue(value);
        if (normalized && estimatorAlgorithmSet.has(normalized.toLowerCase())) {
            return normalized;
        }

        const legacyValue = extractSettingValue(settingsPayload, "useDanielAlgorithm");
        if (legacyValue !== undefined && legacyValue !== null) {
            return "Sunny";
        }

        const fallback = normalizeEstimatorAlgorithmValue(appConfig.defaults.estimatorAlgorithm);
        if (fallback && estimatorAlgorithmSet.has(fallback.toLowerCase())) {
            return fallback;
        }

        return "Sunny";
    }

    function parseAzusaSunnyReferenceHoValue(settingsPayload) {
        const value = extractSettingValue(settingsPayload, "azusaSunnyReferenceHo");
        return normalizeBooleanSetting(value, appConfig.defaults.azusaSunnyReferenceHo);
    }

    function parseEtternaVersionValue(settingsPayload) {
        const value = extractSettingValue(settingsPayload, "etternaVersion");
        const normalized = normalizeEtternaVersionValue(value);
        if (normalized && etternaVersionSet.has(normalized.toLowerCase())) {
            return normalized;
        }

        const fallback = normalizeEtternaVersionValue(appConfig.defaults.etternaVersion);
        if (fallback && etternaVersionSet.has(fallback.toLowerCase())) {
            return fallback;
        }

        return appConfig.defaults.etternaVersion;
    }

    function parseCompanellaEtternaVersionValue(settingsPayload) {
        const value = extractSettingValue(settingsPayload, "companellaEtternaVersion");
        const normalized = normalizeEtternaVersionValue(value);
        if (normalized && companellaEtternaVersionSet.has(normalized.toLowerCase())) {
            return normalized;
        }

        const fallback = normalizeEtternaVersionValue(appConfig.defaults.companellaEtternaVersion);
        if (fallback && companellaEtternaVersionSet.has(fallback.toLowerCase())) {
            return fallback;
        }

        return appConfig.defaults.companellaEtternaVersion;
    }

    function parseGameClientValue(settingsPayload) {
        const value = extractSettingValue(settingsPayload, "gameClient");
        const normalized = normalizeGameClientValue(value);
        return normalized || appConfig.defaults.gameClient || "Auto";
    }

    function parseEnablePauseDetectionValue(settingsPayload) {
        const value = extractSettingValue(settingsPayload, "enablePauseDetection");
        return normalizeBooleanSetting(value, appConfig.defaults.pauseDetectionEnabled);
    }

    function parseEnableResultCacheValue(settingsPayload) {
        const value = extractSettingValue(settingsPayload, "enableResultCache");
        return normalizeBooleanSetting(value, appConfig.defaults.enableResultCache);
    }

    function parseVibroDetectionValue(settingsPayload) {
        const value = extractSettingValue(settingsPayload, "VibroDetection");
        if (value !== undefined && value !== null) {
            return normalizeBooleanSetting(value, appConfig.defaults.vibroDetection);
        }

        const legacyValue = extractSettingValue(settingsPayload, "disableVibroDetection");
        if (legacyValue !== undefined && legacyValue !== null) {
            return !normalizeBooleanSetting(legacyValue, appConfig.defaults.disableVibroDetection);
        }

        return normalizeBooleanSetting(appConfig.defaults.vibroDetection, true);
    }

    function parseEnableEtternaRainbowBarsValue(settingsPayload) {
        const value = extractSettingValue(settingsPayload, "enableEtternaRainbowBars");
        return normalizeBooleanSetting(value, appConfig.defaults.enableEtternaRainbowBars);
    }

    function parseEnableStatusMarqueeValue(settingsPayload) {
        const value = extractSettingValue(settingsPayload, "enableStatusMarquee");
        return normalizeBooleanSetting(value, appConfig.defaults.enableStatusMarquee);
    }

    function parseShowModeTagCapsuleValue(settingsPayload) {
        const value = extractSettingValue(settingsPayload, "showModeTagCapsule");
        return normalizeBooleanSetting(value, appConfig.defaults.showModeTagCapsule);
    }

    function parseEnableNumericDifficultyValue(settingsPayload) {
        const value = extractSettingValue(settingsPayload, "enableNumericDifficulty");
        return normalizeBooleanSetting(value, appConfig.defaults.enableNumericDifficulty);
    }

    function parseCardVisibilityValue(settingsPayload) {
        const value = extractSettingValue(settingsPayload, "cardVisibility");
        const valid = ["DuringPlay", "OutsidePlay", "Always"];
        return valid.includes(value) ? value : appConfig.defaults.cardVisibility;
    }

    function parseEnableOsuThemeValue(settingsPayload) {
        const value = extractSettingValue(settingsPayload, "enableOsuTheme");
        return normalizeBooleanSetting(value, appConfig.defaults.enableOsuTheme);
    }

    function parseEnableFloatingTrianglesValue(settingsPayload) {
        const value = extractSettingValue(settingsPayload, "enableFloatingTriangles");
        return normalizeBooleanSetting(value, appConfig.defaults.enableFloatingTriangles);
    }

    function parseEnableCoverArtValue(settingsPayload) {
        const value = extractSettingValue(settingsPayload, "enableCoverArt");
        return normalizeBooleanSetting(value, appConfig.defaults.enableCoverArt);
    }

    function parseCustomBackgroundColorValue(settingsPayload) {
        const value = extractSettingValue(settingsPayload, "customBackgroundColor");
        const normalized = normalizeCustomBackgroundColorValue(value);
        return normalized ?? "#000000";
    }

    function parseCardOpacityValue(settingsPayload) {
        const value = extractSettingValue(settingsPayload, "cardOpacity");
        const normalized = normalizeCardOpacityValue(value);
        if (normalized && cardOpacitySet.has(normalized.toLowerCase())) {
            return normalized;
        }

        const fallback = normalizeCardOpacityValue(appConfig.defaults.cardOpacity);
        if (fallback && cardOpacitySet.has(fallback.toLowerCase())) {
            return fallback;
        }

        return appConfig.defaults.cardOpacity;
    }

    function parseCardRadiusValue(settingsPayload) {
        const value = extractSettingValue(settingsPayload, "cardRadius");
        const normalized = normalizeCardRadiusValue(value);
        if (normalized && cardRadiusSet.has(normalized.toLowerCase())) {
            return normalized;
        }

        const fallback = normalizeCardRadiusValue(appConfig.defaults.cardRadius);
        if (fallback && cardRadiusSet.has(fallback.toLowerCase())) {
            return fallback;
        }

        return appConfig.defaults.cardRadius;
    }

    function parseCardBgBlurValue(settingsPayload) {
        const value = extractSettingValue(settingsPayload, "cardBgBlur");
        const normalized = normalizeCardBgBlurValue(value);
        if (normalized && cardBgBlurSet.has(normalized.toLowerCase())) {
            return normalized;
        }

        const fallback = normalizeCardBgBlurValue(appConfig.defaults.cardBgBlur);
        if (fallback && cardBgBlurSet.has(fallback.toLowerCase())) {
            return fallback;
        }

        return appConfig.defaults.cardBgBlur;
    }

    function parseEnableUpdateCheckValue(settingsPayload) {
        const value = extractSettingValue(settingsPayload, "enableUpdateCheck");
        if (value !== undefined) {
            return normalizeBooleanSetting(value, appConfig.defaults.enableUpdateCheck);
        }

        const legacyValue = extractSettingValue(settingsPayload, "showTitleIcon");
        return normalizeBooleanSetting(legacyValue, appConfig.defaults.enableUpdateCheck);
    }

    function parseReverseCardExtendDirectionValue(settingsPayload) {
        const value = extractSettingValue(settingsPayload, "reverseCardExtendDirection");
        return normalizeBooleanSetting(value, appConfig.defaults.reverseCardExtendDirection);
    }

    function parseUseOsuFontValue(settingsPayload) {
        const value = extractSettingValue(settingsPayload, "useOsuFont");
        return normalizeBooleanSetting(value, appConfig.defaults.useOsuFont);
    }

    function parseDisplay6kLevelValue(settingsPayload) {
        const value = extractSettingValue(settingsPayload, "display6kLevel");
        return normalizeBooleanSetting(value, appConfig.defaults.display6kLevel);
    }

    function parseSvDetectionValue(settingsPayload) {
        const value = extractSettingValue(settingsPayload, "useSvDetection");
        return normalizeBooleanSetting(value, appConfig.defaults.useSvDetection);
    }

    function parseExtendedEstimationRangeValue(settingsPayload) {
        const value = extractSettingValue(settingsPayload, "extendedEstimationRange");
        return normalizeBooleanSetting(value, appConfig.defaults.extendedEstimationRange);
    }

    function parseWsEndpointValue(settingsPayload) {
        const wsEndpointValue = extractSettingValue(settingsPayload, "wsEndpoint");
        const legacyWsHostValue = extractSettingValue(settingsPayload, "wsHost");
        const fallbackHost = appConfig.defaults.wsEndpoint || appConfig.socketHost;

        if (wsEndpointValue !== undefined && wsEndpointValue !== null) {
            return normalizeWsEndpointValue(wsEndpointValue, fallbackHost);
        }

        if (legacyWsHostValue !== undefined && legacyWsHostValue !== null) {
            return normalizeWsEndpointValue(legacyWsHostValue, fallbackHost);
        }

        return normalizeWsEndpointValue(fallbackHost, "localhost:24050");
    }

    function parseForceSunnyWindowValue(settingsPayload) {
        const value = extractSettingValue(settingsPayload, "forceSunnyWindow");
        return normalizeBooleanSetting(value, appConfig.defaults.forceSunnyWindow);
    }

    function parseEnableLNDifficultyValue(settingsPayload) {
        const value = extractSettingValue(settingsPayload, "enableLNDifficulty");
        return normalizeBooleanSetting(value, appConfig.defaults.enableLNDifficulty);
    }

    function parseEnableAnalyzeLNValue(settingsPayload) {
        const value = extractSettingValue(settingsPayload, "enableAnalyzeLN");
        return normalizeBooleanSetting(value, appConfig.defaults.enableAnalyzeLN);
    }

    function parseEnableAlwaysShowLNDifficultyValue(settingsPayload) {
        const value = extractSettingValue(settingsPayload, "enableAlwaysShowLNDifficulty");
        return normalizeBooleanSetting(value, appConfig.defaults.enableAlwaysShowLNDifficulty);
    }

    function parseEnableTelemetryValue(settingsPayload) {
        const value = extractSettingValue(settingsPayload, "enableTelemetry");
        return normalizeBooleanSetting(value, appConfig.defaults.enableTelemetry);
    }

    return {
        parseEnablePatternValue,
        parseContentBarValue,
        parseSrTextValue,
        parseDebugUseAmountValue,
        parseDiffTextValue,
        parseAutoModeValue,
        parseEstimatorAlgorithmValue,
        parseAzusaSunnyReferenceHoValue,
        parseEtternaVersionValue,
        parseCompanellaEtternaVersionValue,
        parseEnablePauseDetectionValue,
        parseEnableResultCacheValue,
        parseVibroDetectionValue,
        parseEnableEtternaRainbowBarsValue,
        parseEnableStatusMarqueeValue,
        parseShowModeTagCapsuleValue,
        parseEnableNumericDifficultyValue,
        parseCardVisibilityValue,
        parseEnableOsuThemeValue,
        parseEnableFloatingTrianglesValue,
        parseEnableCoverArtValue,
        parseCustomBackgroundColorValue,
        parseCardOpacityValue,
        parseCardRadiusValue,
        parseCardBgBlurValue,
        parseEnableUpdateCheckValue,
        parseReverseCardExtendDirectionValue,
        parseUseOsuFontValue,
        parseSvDetectionValue,
        parseDisplay6kLevelValue,
        parseExtendedEstimationRangeValue,
        parseWsEndpointValue,
        parseForceSunnyWindowValue,
        parseEnableLNDifficultyValue,
        parseEnableAnalyzeLNValue,
        parseEnableAlwaysShowLNDifficultyValue,
        parseEnableTelemetryValue,
        parseGameClientValue,
    };
}
