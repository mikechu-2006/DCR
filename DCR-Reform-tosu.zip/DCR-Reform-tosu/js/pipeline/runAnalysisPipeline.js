// js/pipeline/runAnalysisPipeline.js
// 分析管线纯函数：解析 → 估算分派 → 归一化 → SunnyWindow → 派生值 → Interlude → Pattern → Ett → Companella 二次 Ett。
// 一次调用（worker 单次往返或主线程同步回退）返回全部产物，渲染/缓存/主线程专属逻辑由调用方负责。
//
// 共享模块约束（AGENTS.md）：DOM-free / state-free / JSON-safe，纯函数，Node 与浏览器一致。
// 逐段顺序与 analysis.js 旧估算分派 + 附属段顺序一致（估算 → 归一化 → SunnyWindow → 派生 → Interlude → Pattern → Ett → Companella）；
// 渲染段与缓存逻辑由调用方（analysis.js）负责，本模块不接触。
//
// 错误通道：
//   - 估算器 / SunnyWindow 抛错直接向上传播（与旧行为一致——analysis.js 外层 catch 格式化
//     "Rework failed: ..." 并 resetReworkDisplay；harness 按阶段 catch 记录）。
//   - 附属段（pattern/ett/interlude/companella-ett）各自 try/catch 软失败：字段置空/NaN，
//     错误文本放独立 xxxError 字段（不并入 errors[]）——旧代码的 errors.push 带展示条件
//     （shouldReportEtternaError / isKeycountError 过滤等）依赖调用方主线程状态，
//     由 analysis.js 按旧条件决定是否并入，保证逐字一致。errors[] 恒为空，保留为硬错误预留。

import { estimate } from "../reform/core.js";
import { OsuFileParser } from "../parser/osuFileParser.js";
import { runSunnyEstimatorFromText } from "../estimator/sunnyEstimator.js";
import { runSunnyWindowEstimatorFromText } from "../estimator/sunnyWindowEstimator.js";
import { runDanielEstimatorFromText } from "../estimator/danielEstimator.js";
import { runAzusaEstimatorFromText } from "../estimator/azusaEstimator.js";
import { runRoxyEstimatorFromText } from "../estimator/roxyEstimator.js";
import { runMixedEstimatorFromText } from "../estimator/mixedEstimator.js";
import { analyzePatternFromText } from "../patterns/service.js";
import { analyzeEtternaFromText, DEFAULT_SCORE_GOAL as ETT_DEFAULT_SCORE_GOAL } from "../ett/index.js";
import { calculateInterludeStar } from "../interlude/index.js";

const NORMALIZATION_ALGORITHMS = new Set(["Azusa", "Roxy", "Mixed"]);

// Sunny 结果的 numericDifficulty 恒为 null；Azusa/Roxy 无效回退后的 Sunny 结果同样如此。
// 允许 null 通过可避免主线程冗余重算（与 analysis.js 旧 isValidEstimatorResult 一致）。
// 对 Azusa/Roxy 自身结果行为与 worker 严格版一致：错误结果 star 为 NaN（两边都判无效），
// 成功结果 numericDifficulty 恒为有限值（两边都判有效）。
function isValidResult(result) {
    return Boolean(result)
        && Number.isFinite(result.star)
        && (Number.isFinite(result.numericDifficulty) || result.numericDifficulty === null)
        && typeof result.estDiff === "string";
}

// Pattern report 的 cluster 对象带 format()/Importance getter（patterns/clustering.js:112-131），
// structuredClone / JSON 均无法直接传输（方法触发 DataCloneError）。pipeline 只输出 analysis.js
// 消费的纯数据子集（Category/SVAmount/ModeTag/Clusters/topFiveClusters），getter 求值结果
// （Importance）不输出——analysis.js 消费侧（mergeDuplicateClusters/render）只读数据字段。
function sanitizePatternResult(result) {
    const report = result && typeof result === "object" ? result.report : null;
    if (!report || typeof report !== "object") {
        return { report: null, topFiveClusters: [] };
    }
    const plainClusters = (Array.isArray(report.Clusters) ? report.Clusters : []).map((c) => ({
        Pattern: c?.Pattern ?? null,
        SpecificTypes: c?.SpecificTypes ?? [],
        RatingMultiplier: c?.RatingMultiplier ?? null,
        BPM: c?.BPM ?? null,
        Mixed: c?.Mixed ?? null,
        Amount: c?.Amount ?? null,
    }));
    return {
        report: {
            Clusters: plainClusters,
            Category: report.Category ?? null,
            LNPercent: report.LNPercent ?? null,
            HBRowRatio: report.HBRowRatio ?? null,
            ModeTag: report.ModeTag ?? null,
            SVAmount: report.SVAmount ?? null,
            Duration: report.Duration ?? null,
        },
        topFiveClusters: plainClusters.slice(0, 5),
    };
}

/**
 * 运行完整分析管线（异步：ett WASM 与 interlude 均为异步）。
 *
 * @param {object} input
 * @param {string} input.rawText  .osu 文件文本
 * @param {string} input.estimatorAlgorithm  Sunny / Daniel / Azusa / Roxy / Mixed / Companella
 * @param {object} input.options  显式传入的估算选项（禁止读 state）：speedRate, odFlag, cvtFlag,
 *   withGraph, forceSunnyReferenceHo, forceSunnyWindow, enableAnalyzeLN,
 *   enableAlwaysShowLNDifficulty, display6kLevel, extendedEstimationRange,
 *   withPattern, withEtterna, withInterlude, etternaVersion, companellaEtternaVersion
 * @param {object} [input.parsed]  可选：已 process() 的 OsuFileParser 实例（Node/harness 复用解析，
 *   浏览器 worker 不传——worker 内自行解析一次）
 * @returns {Promise<{ rework: object, actualEstimatorAlgorithm: string, sunnyStar: number|null,
 *   sunnyWindow: object|null, sixKConst: number|null,
 *   ppMetrics: { star: number, variety: number, accScalar: number, totalNotes: number,
 *     spikiness: number, switches: number }|null,  // 仅 options.withPpMetrics === true 时输出
 *   vibro: { star: number, eligible: boolean },
 *   parsedSummary: { metadata: object, lnRatio: number, columnCount: number },
 *   patternReport: object|null, patternTopFiveClusters: Array|null, patternError: string|null,
 *   ettResult: object|null, ettError: string|null,
 *   interludeStar: number, interludeError: string|null,
 *   companellaEttResult: object|null, companellaEttError: string|null,
 *   errors: string[] }>}
 */
export async function runAnalysisPipeline({ rawText, estimatorAlgorithm, options = {}, parsed = null, reform = null }) {
    // 1. 解析一次（可选复用外部已解析实例），估算器/归一化/SunnyWindow/Interlude 共享同一实例。
    const parser = (parsed && typeof parsed?.getParsedData === "function")
        ? parsed
        : new OsuFileParser(rawText);
    if (!parsed || !parsed?.process) {
        parser.process();
    }
    const parsedData = parser.getParsedData();
    const parsedSummary = {
        metadata: parsedData.metaData || {},
        lnRatio: Number(parsedData.lnRatio) || 0,
        columnCount: Number(parsedData.columnCount) || 0,
    };

    // ── 马拉松时长修正：估算器内嵌前置（按需）──────────────────────────
    // 修正由 Azusa/Roxy 估算器本体应用（options.marathonCorrection 注入
    // { durationS, ettValues }）。durationS 恒可同步计算（noteStarts 首尾差，
    // 未按速率缩放）；ettValues 需 WASM（异步）→ 仅在可能触发修正的候选上
    // （>300s 且 4K 且算法 ∈ {Azusa, Roxy, Mixed}）提前计算一次 Ett，并复用于
    // 段 9/10（不重复计算，perf 约束见 docs/breakings/2026-08-09-perf-analysis-pipeline.md）。
    const marathonDurationS = (() => {
        const starts = parsedData.noteStarts;
        if (!Array.isArray(starts) || starts.length < 2) return 0;
        return (Math.max(...starts) - Math.min(...starts)) / 1000;
    })();
    const isMarathonRcCandidate = estimatorAlgorithm === "Azusa"
        || estimatorAlgorithm === "Roxy"
        || estimatorAlgorithm === "Mixed";
    let marathonEttReuse = null; // { result?: object, error?: string }
    if (isMarathonRcCandidate && parsedSummary.columnCount === 4 && marathonDurationS > 300) {
        try {
            marathonEttReuse = { result: await analyzeEtternaFromText(rawText, {
                musicRate: options.speedRate ?? 1,
                scoreGoal: ETT_DEFAULT_SCORE_GOAL,
                cvtFlag: options.cvtFlag,
                etternaVersion: options.etternaVersion,
            }) };
        } catch (err) {
            marathonEttReuse = { error: String(err?.message || err) };
        }
        if (marathonEttReuse.result) {
            options = {
                ...options,
                marathonCorrection: {
                    durationS: marathonDurationS,
                    ettValues: marathonEttReuse.result.values,
                },
            };
        }
    }

    // 归一化星数复用决策（决策表见 .omo/evidence/task-11-pipeline.txt）：
    // 仅当算法内部 Sunny 与归一化调用（runSunnyEstimatorFromText(rawText, options)）
    // 使用相同 options + 相同文本时可复用；通过 precomputedSunnyResult 把同一份 Sunny
    // 结果喂给估算器，并直接取其 star 完成归一化（避免多跑一次 Sunny）：
    //   - Mixed：sunnyBaseline 用原 options（含 withGraph）→ 一致 → 复用
    //   - Azusa(forceSunnyReferenceHo=false)：内部 sunnyOptions = options → 一致 → 复用
    //   - Azusa(forceSunnyReferenceHo=true)：内部 sunnyOptions = {...options, cvtFlag:"HO"}
    //     → cvtFlag 不一致 → 独立计算（且不可传 precomputedSunnyResult，否则数值语义改变）
    //   - Roxy：内部 reference sunny 用 canonicalizeOsuTiming 改写后的 analysisText
    //     （即使 speedRate=1 也做常数平移），且 metaOptions 硬编码 precomputedSunnyResult:null
    //     → 无法证明一致 → 独立计算
    const needsNormalization = NORMALIZATION_ALGORITHMS.has(estimatorAlgorithm);
    const canReuseSunny = needsNormalization
        && (estimatorAlgorithm === "Mixed"
            || (estimatorAlgorithm === "Azusa" && options.forceSunnyReferenceHo === false));
    let sharedSunnyResult = null;
    if (canReuseSunny) {
        sharedSunnyResult = runSunnyEstimatorFromText(rawText, options, parser);
    }

    // 2. 估算分派（白名单与 Azusa/Roxy 无效回退 Sunny 语义同 compute.worker.js:17-54）。
    let selectedRework = null;
    let actualEstimatorAlgorithm = estimatorAlgorithm;

    if (estimatorAlgorithm === "Daniel") {
        selectedRework = runDanielEstimatorFromText(rawText, options, parser);
    } else if (estimatorAlgorithm === "Azusa") {
        const azusaOpts = {
            ...options,
            forceSunnyReferenceHo: options.forceSunnyReferenceHo !== false,
            ...(sharedSunnyResult ? { precomputedSunnyResult: sharedSunnyResult } : {}),
        };
        selectedRework = runAzusaEstimatorFromText(rawText, azusaOpts, parser);
        actualEstimatorAlgorithm = selectedRework?.actualEstimatorAlgorithm || actualEstimatorAlgorithm;
        if (!isValidResult(selectedRework)) {
            // 回退 Sunny：可复用场景直接复用同一份结果（逐位一致），否则独立计算。
            selectedRework = sharedSunnyResult || runSunnyEstimatorFromText(rawText, options, parser);
            actualEstimatorAlgorithm = "Sunny";
        }
    } else if (estimatorAlgorithm === "Roxy") {
        selectedRework = runRoxyEstimatorFromText(rawText, options, parser);
        actualEstimatorAlgorithm = selectedRework?.actualEstimatorAlgorithm || actualEstimatorAlgorithm;
        if (!isValidResult(selectedRework)) {
            selectedRework = runSunnyEstimatorFromText(rawText, options, parser);
            actualEstimatorAlgorithm = "Sunny";
        }
    } else if (estimatorAlgorithm === "Mixed") {
        const mixedOpts = sharedSunnyResult
            ? { ...options, precomputedSunnyResult: sharedSunnyResult }
            : options;
        selectedRework = runMixedEstimatorFromText(rawText, mixedOpts, parser);
        // Mixed 自动路由到 Roxy/Azusa/Daniel/Companella/Sunny，
        // 从结果读取实际命中的子算法（与 Azusa/Roxy 分支同语义）。
        actualEstimatorAlgorithm = selectedRework?.actualEstimatorAlgorithm || actualEstimatorAlgorithm;
    } else if (estimatorAlgorithm === "Companella") {
        // Companella 本体在主线程异步追加（§7.5），此处跑 Sunny 打底。
        selectedRework = runSunnyEstimatorFromText(rawText, options, parser);
    } else {
        // Sunny / 其他
        selectedRework = runSunnyEstimatorFromText(rawText, options, parser);
        actualEstimatorAlgorithm = "Sunny";
    }

    // 3. vibro 判定输入：归一化前的 star（与 analysis.js 旧 selectedRework?.star 顺序一致）。
    //    实际 isVibroMap 判定（detectVibro，浏览器专属）留在主线程，等 ettResult 就绪后执行。
    const vibroStar = Number(selectedRework?.star);
    const vibro = {
        star: vibroStar,
        eligible: Number.isFinite(vibroStar) && vibroStar > 5.0,
    };

    // 4. 归一化：Azusa/Roxy/Mixed 未回退时 star 统一为 Sunny 原始 sr（星数胶囊恒显 Sunny 口径；
    //    Daniel 独立算法排除；Companella/Sunny 本就是 Sunny sr）。
    //    保留 sunnyResult 对象引用（含 ppMetrics 挂载），下方 ppMetrics 组装复用同一份结果。
    let rework = selectedRework;
    let sunnyStar = null;
    let normalizationSunnyResult = null;
    if (NORMALIZATION_ALGORITHMS.has(actualEstimatorAlgorithm) || estimatorAlgorithm === "Mixed") {
        normalizationSunnyResult = sharedSunnyResult || runSunnyEstimatorFromText(rawText, options, parser);
        sunnyStar = Number(normalizationSunnyResult.star);
        rework = { ...selectedRework, star: sunnyStar };
    }

    // 4b. ppMetrics（withPpMetrics，Task 9）：全部字段来自同一个 Sunny 结果对象，star 取该结果 star
    //    （Sunny 原始 sr，与星数胶囊口径一致）。来源按算法：
    //    - Azusa/Roxy/Mixed：归一化 sunnyResult（sharedSunnyResult 或上方独立计算）
    //    - Daniel：withPpMetrics 时在 pipeline 内跑专用 Sunny pass（同 options + withPpMetrics:true）
    //    - Sunny/Companella / Azusa/Roxy 回退后的 Sunny：selectedRework 即 Sunny 结果
    //    失败/无 ppMetrics → null（软失败，不进 errors[]）；关闭时零额外计算、零输出字段。
    let ppMetrics = null;
    if (options.withPpMetrics === true) {
        try {
            let sunnySrc = null;
            if (NORMALIZATION_ALGORITHMS.has(actualEstimatorAlgorithm) || estimatorAlgorithm === "Mixed") {
                sunnySrc = normalizationSunnyResult;
            } else if (estimatorAlgorithm === "Daniel") {
                sunnySrc = runSunnyEstimatorFromText(rawText, { ...options, withPpMetrics: true }, parser);
            } else {
                sunnySrc = selectedRework;
            }
            const m = sunnySrc?.ppMetrics;
            if (sunnySrc && m && Number.isFinite(Number(sunnySrc.star))) {
                ppMetrics = {
                    star: Number(sunnySrc.star),
                    variety: m.variety,
                    accScalar: m.accScalar,
                    totalNotes: m.totalNotes,
                    spikiness: m.spikiness,
                    switches: m.switches,
                };
            }
        } catch (err) {
            ppMetrics = null; // 软失败：与附属段语义一致，不并入 errors[]
        }
    }

    // 5. SunnyWindow（forceSunnyWindow）：calculateSunny + calculateLN（带 parsed + enableAnalyzeLN）。
    //    try/catch 软失败（与其他附属段一致）：对个别谱面（如转换文本边界）抛错时
    //    不应拖垮整个 pipeline——否则卡片偶发 No data（用户：切走再切回才恢复）。
    let sunnyWindow = null;
    let sunnyWindowError = null;
    if (options.forceSunnyWindow) {
        try {
            sunnyWindow = runSunnyWindowEstimatorFromText(
                rawText,
                { ...options, enableAnalyzeLN: options.enableAnalyzeLN === true },
                parser,
            );
        } catch (err) {
            sunnyWindowError = String(err?.message || err);
        }
    }

    // 6. 6K 定数：display6kLevel && 6K 时按归一化后 star（6K 下恒为 Sunny sr）换算，2 位小数。
    let sixKConst = null;
    if (options.display6kLevel && parsedSummary.columnCount === 6) {
        const sunnySrc = Number(rework.star);
        if (Number.isFinite(sunnySrc) && sunnySrc > 0) {
            sixKConst = sunnySrc * 200 / 81 + 7 / 6;
            sixKConst = Math.round(sixKConst * 100) / 100;
        }
    }

    // 7-10. 附属段（analysis.js:606-738 并入）。顺序与旧主线程执行顺序一致：Interlude → Pattern
    //    → Ett → Companella 二次 Ett。各自 try/catch 软失败，字段置空/NaN，错误文本独立记录。

    // 7. Interlude（吃 sharedParsed——chartBuilder.buildInterludeRows 支持已解析 parser 实例）。
    let interludeStar = Number.NaN;
    let interludeError = null;
    if (options.withInterlude) {
        try {
            interludeStar = await calculateInterludeStar(parser, options.speedRate ?? 1, options.cvtFlag);
        } catch (err) {
            interludeError = String(err?.message || err);
        }
    }

    // 8. Pattern（保留 patternOsuParser 独立解析，不改语义；输出仅含纯数据子集）。
    let patternReport = null;
    let patternTopFiveClusters = null;
    let patternError = null;
    if (options.withPattern) {
        try {
            const sanitized = sanitizePatternResult(analyzePatternFromText(rawText));
            patternReport = sanitized.report;
            patternTopFiveClusters = sanitized.topFiveClusters;
        } catch (err) {
            patternError = String(err?.message || err);
        }
    }

    // 9. Ett（WASM，worker 内用 calc.js 现有 loader；import.meta.url 按模块文件解析，worker 同源可 fetch）。
    //    若马拉松前置已算过（>300s 的 4K RC 候选），直接复用其结果，避免二次 WASM 计算（perf 约束）。
    let ettResult = null;
    let ettError = null;
    let ettErrorCode = null;
    if (options.withEtterna) {
        if (marathonEttReuse) {
            if (marathonEttReuse.result) {
                ettResult = marathonEttReuse.result;
            } else {
                ettError = marathonEttReuse.error;
            }
        } else {
            try {
                ettResult = await analyzeEtternaFromText(rawText, {
                    musicRate: options.speedRate ?? 1,
                    scoreGoal: ETT_DEFAULT_SCORE_GOAL,
                    cvtFlag: options.cvtFlag,
                    etternaVersion: options.etternaVersion,
                });
            } catch (err) {
                ettError = String(err?.message || err);
                ettErrorCode = typeof err?.code === "string" ? err.code : null;
            }
        }
    }

    // 10. Companella 二次 Ett：Companella/Mixed && 4K && companellaEtternaVersion 与主版本不同时
    //     在同一次 pipeline 内完成（一次往返）。失败不阻断（旧行为 console.warn + 回退主 ett values）。
    let companellaEttResult = null;
    let companellaEttError = null;
    const needsCompanellaData = estimatorAlgorithm === "Companella" || estimatorAlgorithm === "Mixed";
    const resolvedCompanellaEtternaVersion = String(options.companellaEtternaVersion || "").trim()
        || options.etternaVersion;
    if (needsCompanellaData
        && parsedSummary.columnCount === 4
        && options.etternaVersion
        && resolvedCompanellaEtternaVersion !== options.etternaVersion) {
        try {
            companellaEttResult = await analyzeEtternaFromText(rawText, {
                musicRate: options.speedRate ?? 1,
                scoreGoal: ETT_DEFAULT_SCORE_GOAL,
                cvtFlag: options.cvtFlag,
                etternaVersion: resolvedCompanellaEtternaVersion,
            });
        } catch (err) {
            companellaEttError = String(err?.message || err);
        }
    }

    // 11. 马拉松时长修正由估算器本体完成（见前置段：options.marathonCorrection 注入）。
    //     此处无派生段——修正后的数值化难度即估算器输出（语义层即算法层）。

    let reformResult = null;
    if (reform) {
        const { method, chart } = reform;
        try {
            if (parsedSummary.columnCount !== 4 || !chart.supported) {
                reformResult = { method, state: "unsupported" };
            } else {
                const rawSunny = method === "Sunny"
                    ? runSunnyEstimatorFromText(rawText, { speedRate: chart.rate }, parser).star
                    : undefined;
                reformResult = await estimate(method, chart, rawSunny);
            }
        } catch (error) {
            reformResult = { method, state: "error", error: error.message };
        }
    }
    return {
        reformResult,
        rework,
        actualEstimatorAlgorithm,
        sunnyStar,
        sunnyWindow,
        sixKConst,
        vibro,
        ...(options.withPpMetrics === true ? { ppMetrics } : {}),
        parsedSummary,
        patternReport,
        patternTopFiveClusters,
        patternError,
        ettResult,
        ettError,
        ettErrorCode,
        interludeStar,
        interludeError,
        companellaEttResult,
        companellaEttError,
        errors: [],
    };
}
